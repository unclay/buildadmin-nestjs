import { Injectable } from "@nestjs/common";
// import { CoreApiService } from "../../../core/services/api.service";

@Injectable()
export class AuthRuleService {
    constructor() {
    }
    index() {
        return '123d';
    }
}