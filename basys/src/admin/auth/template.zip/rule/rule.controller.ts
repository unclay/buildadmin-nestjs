import { Controller, Get } from "@nestjs/common";
import { AuthRuleService } from "./rule.service";

@Controller('admin/auth.rule')
export class AuthRuleController {
    constructor(private ruleService: AuthRuleService) {}
    @Get('index')
    async index() {
        return this.ruleService.index();
    }
}